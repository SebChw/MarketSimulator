/**
 * Since market Index is a little bit more complicated asset it has separate
 * package
 */
package market.assets.marketIndex;
