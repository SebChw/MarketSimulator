/**
 * Package with all type of goods we can buy/sell
 */

package market.assets;
