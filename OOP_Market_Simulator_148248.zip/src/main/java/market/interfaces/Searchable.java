package market.interfaces;

public interface Searchable {
    public abstract String getSearchString();
}
