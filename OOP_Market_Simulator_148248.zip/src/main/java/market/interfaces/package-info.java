/**
 * Just definitions of miscelenous interfaces which are implemented by some
 * objects.
 */

package market.interfaces;
