/**
 * Tools for creating a container of all objects in the simulation, using which
 * different objects can communicate with one another.
 */

package market.world;
