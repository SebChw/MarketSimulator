/**
 * Package with different type of traders, each of them behaves a little bit
 * differently.
 */
package market.traders;
