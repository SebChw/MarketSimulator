/**
 * Objects on which we can buy and sell differents goods
 */

package market.markets;
