/**
 * Package with assets rates rules defined. We can take different factors into
 * account while changing rate of some asset
 */

package market.priceRules;
