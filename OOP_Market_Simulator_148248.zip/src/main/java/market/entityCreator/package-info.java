
/**
 * Package with tools needed to create all kind of object in the simulation.
 */
package market.entityCreator;