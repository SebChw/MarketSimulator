/**
 * Tools for handiling single transaction between Dealer and Trader.
 */

package market.transactions;
