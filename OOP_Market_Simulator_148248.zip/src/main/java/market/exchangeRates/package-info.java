/**
 * Tools for managing rates of different assets
 */

package market.exchangeRates;
